import cv2
import time
import smtplib
import os
from email.message import EmailMessage
from datetime import datetime
from twilio.rest import Client

# Ensure folders exist
if not os.path.exists("Captured_Faces"):
    os.makedirs("Captured_Faces")

if not os.path.exists("Captured_Videos"):
    os.makedirs("Captured_Videos")

# Haar Cascade
face_cascade = cv2.CascadeClassifier(
    r"C:\Users\vansh\Downloads\Home-surveillance-system-using-Python-master (2)\haarcascade_frontalface_default.xml"
)

# Email Configuration
EMAIL_SENDER = "vanshusharma4045@gmail.com"
EMAIL_PASSWORD = "ajze hmsa uxwr jaro"
EMAIL_RECEIVER = "ckanak924@gmail.com"

# Twilio SMS Configuratio
TWILIO_ACCOUNT_SID = "AC98be73f2bf91de0f27bf7a916cc6ce7b"
TWILIO_AUTH_TOKEN = "b04be6abc651986e8d96fefc2c942f9b" 
TWILIO_PHONE_NUMBER = "+16182279978"
USER_PHONE_NUMBER = "+918295147587"

def send_email(image_path):
    """Send email notification with attached face image."""
    msg = EmailMessage()
    msg["Subject"] = "Home Surveillance Alert - Face Detected!"
    msg["From"] = EMAIL_SENDER
    msg["To"] = EMAIL_RECEIVER
    msg.set_content("A face has been detected by your surveillance system. See the attached image.")

    with open(image_path, "rb") as f:
        img_data = f.read()
        msg.add_attachment(img_data, maintype="image", subtype="jpeg", filename=os.path.basename(image_path))

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(EMAIL_SENDER, EMAIL_PASSWORD)
            server.send_message(msg)
        print("Email sent successfully!")
    except Exception as e:
        print(f"Error sending email: {e}")

def send_sms():
    """Send SMS alert using Twilio."""
    try:
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        message = client.messages.create(
            body="🔔 Home Surveillance Alert: Face detected on camera!",
            from_=TWILIO_PHONE_NUMBER,
            to=USER_PHONE_NUMBER
        )
        print("SMS sent successfully!")
    except Exception as e:
        print(f"Error sending SMS: {e}")

# Open camera
video = cv2.VideoCapture(0)
frame_width = int(video.get(3))
frame_height = int(video.get(4))
video_name = datetime.now().strftime("Captured_Videos/video_%Y-%m-%d_%H-%M-%S.avi")
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter(video_name, fourcc, 20.0, (frame_width, frame_height))

# Cooldown setup
last_email_time = 0
email_cooldown = 10  # seconds

print("System started. Press 'Esc' to stop and save video.")

while True:
    check, frame = video.read()
    if not check:
        break

    out.write(frame)  # Save frame to video
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=10)

    for x, y, w, h in faces:
        img = cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 3)

        # Save face
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        image_path = f"Captured_Faces/face_{timestamp}.jpg"
        cv2.imwrite(image_path, frame)

        # Send alerts
        if time.time() - last_email_time > email_cooldown:
            send_email(image_path)
            send_sms()
            last_email_time = time.time()

    cv2.imshow("Home Surveillance", frame)

    key = cv2.waitKey(1)
    if key == 27:  # ESC
        print("ESC pressed. Saving and exiting.")
        break

# Release
video.release()
out.release()
cv2.destroyAllWindows()
                                                     